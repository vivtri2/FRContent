# use requests to get full HTML
import requests

url = 'https://www.allsides.com/media-bias/media-bias-ratings'

r = requests.get(url)

# print(r.content[:100])

# Use BeautifulSoup4 to parse

from bs4 import BeautifulSoup

soup = BeautifulSoup(r.content, 'html.parser')

rows = soup.select('tbody tr')

row = rows[0]

name = row.select_one('.source-title').text.strip()

print(name)

# News source page link
allsides_page = row.select_one('.source-title a')['href']
allsides_page = 'https://www.allsides.com' + allsides_page

print(allsides_page)

# grab the rating system using the link from inspecting the image
bias = row.select_one('.views-field-field-bias-image a')['href']
bias = bias.split('/')[-1]

print (bias)

# community feedback data
agree = row.select_one('.agree').text
agree = int(agree)

disagree = row.select_one('.disagree').text
disagree = int(disagree)

agree_ratio = agree / disagree

print(f"Agree: {agree}, Disagree: {disagree}, Ratio {agree_ratio:.2f}")

# function that mimics the javascript function for ranking
def get_agreeance_text(ratio):
	if ratio > 3: return "Absolutely Agrees"
	elif 2 < ratio <= 3: return "Strongly Agrees"
	elif 1.5 < ratio <= 2: return "Agrees"
	elif 1 < ratio <= 1.5: return "Somewhat Agrees"
	elif ratio == 1: return "Neutral"
	elif 0.67 < ratio < 1: return "Somewhat Disagrees"
	elif 0.5 < ratio <= 0.67: return "Disagrees"
	elif 0.33 < ratio <= 0.5: return "Strongly Disagrees"
	elif ratio <= 0.33: return "Absolutely Disagrees"
	else: return None

print (get_agreeance_text(1.27)) # Fix this later

#loop that gets data from every row on all pages:
pages = [
	'https://www.allsides.com/media-bias/media-bias-ratings',
	'https://www.allsides.com/media-bias/media-bias-ratings?page=1',
	'https://www.allsides.com/media-bias/media-bias-ratings?page=2'
]

from time import sleep

data = []

for page in pages:
	r = requests.get(page)
	soup = BeautifulSoup(r.content, 'html.parser')

	rows = soup.select('tbody tr')

	for row in rows:
		d = dict()

		d['name'] = row.select_one('.source-title').text.strip()
		d['allsides_page'] = 'https://www.allsides.com' + row.select_one('.source-title a')['href']
		d['bias'] = row.select_one('.views-field-field-bias-image a')['href'].split('/')[-1]
		d['agree'] = int(row.select_one('.agree').text)
		d['disagree'] = int(row.select_one('.disagree').text)
		d['agree_ratio'] = d['agree'] / d['disagree']
		d['agreeance_text'] = get_agreeance_text(d['agree_ratio'])

		data.append(d)

	sleep(10)

from copy import deepcopy
from tqdm import tqdm #for status bar tqdm_notebook for jupyter

for d in tqdm(data): #Jupyternotebook syntax
	r = requests.get(d['allsides_page'])
	soup = BeautifulSoup(r.content, 'html.parser')

	try:
		website = soup.select_one('.www')['href']
		d['website'] = website
	except TypeError:
		pass

import json

with open('allsides.json', 'w') as f:
	json.dump(data, f)

with open('allsides.json', 'r') as f:
	data = json.load(f)