# Vivek Trivedi 10/02/2019

import pandas as pd
from sodapy import Socrata
import json

client = Socrata("data.cityofchicago.org", None)

results = client.get("wrvz-psew",
                     where="trip_start_timestamp between '2013-12-01' and '2014-01-01'")

results_df = pd.DataFrame.from_records(results)

print("taxi API results: ")
print(results_df.head())
print(results_df.columns)
print(results_df['fare'].describe())

fares=results_df['fare'].copy()
fares=fares.astype('float')
print(fares.describe())

with open('data.json', 'w') as outfile:
    json.dump(results, outfile)
