import UIKit

//This part should have the // taken outvvv
// func calculator (n1: Int, n2: Int, operation: (Int, Int) -> Int) -> Int {
//     return operation(n1, n2)
// }
//This part should have the // taken out^^^

//THIS IS THE FIRST OLD CODE
//
// func multiply (no1: Int, no2: Int) -> Int {
//     return no1 * no2
//
//
// calculator(n1: 2, n2: 3, operation: multiply)
//--------------------------------------------------//

//This is where the new code begins with explanation//
//
//This closure occured by deleting "func multiply" then taking the first bracket{ and moving it to the beginning and replacing where the first bracket was with "in"
//Then I click on the closing bracket for that "function" so it highlighted everything within the bracket and dragged that to where I called the "multiply function after "operation:"
//
//
//THIS IS THE SECOND OLD CODE
//
// calculator(n1: 2, n2: 3, operation: { (no1, no2) in no1 * no2})
//
//we can delete "Int" after no1 because Swift knows how to infer datatypes
//inside of a closure we do not need as "return" keyword because it can infer there needs otbe an operation that needs to be carried out
//--------------------------------------------------//

//THIS IS THE THIRD OLD CODE -- MOST COMPLEX WAY OF WRITING IS THE LAST ONE
//
// let result = calculator(n1: 2, n2: 3, operation: {$0 * $1})
// print(result)
//
//we can use anonymous parameters names
//$0 refers to "first parameter"; $1 refers to "second parameter"; etc
//We assign result to a constant and print the constant and we get the value
//--------------------------------------------------//

//THIS IS THE MOST COMPLEX WAY OF WRITING WHAT WE HAD WRITTEN IN THE BEGINNING
//
// let result = calculator(n1: 2, n2: 3) {$0 * $1}
//  print(result)
//
//if the last parameter (operation:) is a closure ({$0 * $1})
//we can omit the closure name (operation:) and just close out the input section (n1: 2, n2: 3) with a parenthesis and have the closure ({$0 * $1}) trailing at the end

//--------------------------------------------------//
//--------------------------------------------------//
//--------------------------------------------------//
//Now we learn how to use closures in a real life example//

import UIKit

let array = [6,2,3,9,4,1] //we can use a for loop to iterate through each item and add +1 to each of the items
//we use the function "map" that allows us to transform every single item in a collection type
//a collection type are "arrays" or "dictionaries" -- basically collection of items
//need a rule for our array

//FIRST OLD CODE
// func addOne (n1: Int) -> Int {
//     return n1 + 1
// }
//
// array.map(addOne)

//SECOND OLD CODE
//
// array.map({(n1: Int) -> Int in n1 + 1})

//THIRD OLD CODE
//
// array.map{$0 + 1}

//THIS IS A BONUS CODE SHOWING HOW WE CAN USE THE MAP FUNCTION TO CONVERT A COLLECTION TYPE TO A STRING
//
let newArray = array.map{"\($0 + 1)"}
print(newArray)
