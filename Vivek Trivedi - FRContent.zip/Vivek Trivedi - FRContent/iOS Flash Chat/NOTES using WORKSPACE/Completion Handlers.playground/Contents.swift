import UIKit

class Firebase {
    func createUser (username: String, password: String, completion: (Bool, Int) -> Void) {
        //Networks with google's webservers and registers our user in our Firebase database but we just say "does fsomething time consuming"
        var isSuccess = true
        var userID = 123
        
        completion(isSuccess, userID)
    }
}

//this is a completion handler with a closure
class MyApp {
    
    func registerButtonPressed() {
        let firebase = Firebase()
        
        firebase.createUser(username: "Vivek", password: "123456") {
            (isSuccess : Bool, userID: Int) in
            
            print("registration is successful: \(isSuccess)")
            print("userID is: \(userID)")
            
        } //need a way for background process to let us know it was complete and successful
    }
}

let myApp = MyApp()
myApp.registerButtonPressed()

//NOTES// -- referring to the Flash Chat App
//Closure only gets triggered once hte process of creating users is completed in the Firebase authentication class (referring to the chat app)
//Happening in the background (creating the username and password)
//Once that process is completed, we get a "callback" in the form of a "COMPLETION HANDLER"
//and then we deal with that "callback" by taking the user to the chatview screen
//Shows us the app isn't frozen while the user is being created in the background by google's webservers and registering them into our Firebase database
//And only when it completes do we get a message and get to go to the next page
